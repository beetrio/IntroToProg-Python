#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   DGrubbs
# Date:  May 3, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   DGrubbs, 05/03/2017, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#
import os

#-- Data --#
strData = ""
dicRow = {}
lstTable = []

# Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.

objFile = open(os.path.abspath("Todo.txt"), "r")
for row in objFile:
    strData = row.split(",")
    dicInitial = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
    lstTable.append(dicInitial)
objFile.close()

#-- Input/Output --#
# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5]: "))
    print()#adding a new line

# -- Processing --#
    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("-" * 5, "Current data in Todo.txt", "-" * 5)
        for row in lstTable:
            print("Task: ", row["Task"], "\tPriority: ", row["Priority"])
        input("\nPress 'Enter' to continue ")

    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        dicRowNew = {}
        print("-" * 5, "Add a new task and priority in Todo.txt", "-" * 5)
        dicRowNew["Task"] = input("What task would you like to add? ")
        dicRowNew["Priority"] = input("Task Priority? [High | Low] ")
        lstTable.append(dicRowNew)
        input("\nPress 'Enter' to continue ")

    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        print("-" * 5, "Remove an existing task from Todo.txt", "-" * 5)
        print("Current tasks available to remove:\n{}\n".format(lstTable))
        strDeleteTask = input("What task would you like to remove? ")
        for taskRemove in lstTable:
            if taskRemove["Task"].lower() == strDeleteTask.lower():
                lstTable.remove(taskRemove)
                print(taskRemove["Task"], "has been removed.\n")
            # else:
            #     print("{} does not exist as a task.".format(strDeleteTask))
        print("Remaining tasks: ")
        for tasks in lstTable:
            print("Task: ", tasks["Task"], "\tPriority: ", tasks["Priority"])
        input("\nPress 'Enter' to continue ")

    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        print("-" * 5, "Save data to Todo.txt", "-" * 5)
        objFile = open(os.path.abspath("Todo.txt"), "w")
        for dicRow in lstTable:
            objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n" )
        objFile.close()
        print("Your data has been saved to Todo.txt")
        input("\nPress 'Enter' to continue ")

    elif (strChoice == '5'):
        print("Exiting the program...")
        break #and Exit the program