#-------------------------------------------------
# Title: Working with Dictionaries
# Dev:   DGrubbs
# Date:  May 13, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   DGrubbs, 05/13/2017, Added code to complete assignment 6
#-------------------------------------------------
import os


#-- Data --#
strData = ""
dicRow = {}
lstTable = []

# Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.

objFile = open(os.path.abspath("Todo.txt"), "r")
for row in objFile:
    strData = row.split(",")
    dicInitial = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
    lstTable.append(dicInitial)
objFile.close()


# This class has multiple functions that will be called as a user makes
# choices from the menu
class ToDo(object):
    """Working with ToDo Tasks"""
    @staticmethod
    def CurrentTasks():
        """View current list of tasks."""
        for row in lstTable:
            print("Task: ", row["Task"], "\tPriority: ", row["Priority"])

    @staticmethod
    def AddTask():
        """Add a new task."""
        dicRowNew = {}
        dicRowNew["Task"] = input("What task would you like to add? ")
        dicRowNew["Priority"] = input("Task Priority? [High | Low] ")
        lstTable.append(dicRowNew)

    @staticmethod
    def RemoveTask():
        """Remove a task."""
        print("Current tasks available to remove:\n{}\n".format(lstTable))
        strDeleteTask = input("What task would you like to remove? ")
        for taskRemove in lstTable:
            if taskRemove["Task"].lower() == strDeleteTask.lower():
                lstTable.remove(taskRemove)
                print(taskRemove["Task"], "has been removed.\n")
        print("Remaining tasks: ")
        for tasks in lstTable:
            print("Task: ", tasks["Task"], "\tPriority: ", tasks["Priority"])

    @staticmethod
    def SaveTask():
        """Save task(s) to Todo.txt."""
        objFile = open(os.path.abspath("Todo.txt"), "w")
        for dicRow in lstTable:
            objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
        objFile.close()

    @staticmethod
    def ExitProgram():
        """Exit the program."""
        return "Exiting the program..."


#-- Input/Output --#
# Step 2 - Display a menu of choices to the user
def taskMenu():
    while(True):
        print ("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        strChoice = str(input("Which option would you like to perform? [1 to 5]: "))
        print()#adding a new line

    # -- Processing --#
        # Step 3 -Show the current items in the table
        if (strChoice.strip() == '1'):
            print("-" * 5, "Current data in Todo.txt", "-" * 5)
            ToDo.CurrentTasks()
            input("\nPress 'Enter' to continue ")

        # Step 4 - Add a new item to the list/Table
        elif(strChoice.strip() == '2'):
            print("-" * 5, "Add a new task and priority in Todo.txt", "-" * 5)
            ToDo.AddTask()
            input("\nPress 'Enter' to continue ")

        # Step 5 - Remove a new item to the list/Table
        elif(strChoice == '3'):
            print("-" * 5, "Remove an existing task from Todo.txt", "-" * 5)
            ToDo.RemoveTask()
            input("\nPress 'Enter' to continue ")

        # Step 6 - Save tasks to the ToDo.txt file
        elif(strChoice == '4'):
            print("-" * 5, "Save data to Todo.txt", "-" * 5)
            ToDo.SaveTask()
            print("Your data has been saved to Todo.txt")
            input("\nPress 'Enter' to continue ")

        elif (strChoice == '5'):
            #print("Exiting the program...")
            AllDone = ToDo.ExitProgram()
            print(AllDone)
            break #and Exit the program

taskMenu()